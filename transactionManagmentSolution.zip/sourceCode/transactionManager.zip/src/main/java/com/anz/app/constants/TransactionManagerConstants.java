package com.anz.app.constants;

/**
 * Contains all the constants
 * @author Mathura
 *
 */
public class TransactionManagerConstants {
	
	public static String[] HEADERS = { "transactionId", "fromAccountId", "toAccountId", "createdAt", "amount",
			"transactionType", "relatedTransaction" };

	public static final String REVERSAL = "REVERSAL";
	public static final String PAYMENT = "PAYMENT";
	
	public static final String DATE_PATTERN = "dd/MM/yyyy HH:mm:ss";
	public static final String DECIMAL_NUMBER_FORMAT = "+#,##0.00;-#";
	
	public static final String CREATED_AT = "createdAt";
	public static final String FROM_ACCOUNT_ID = "fromAccountId";
	public static final String TO_ACCOUNT_ID = "toAccountId";
	public static final String AMOUNT = "amount";
	public static final String TRANSACTION_TYPE = "transactionType";
	public static final String TRANSACTION_ID = "transactionId";
	public static final String RELATED_TRANSACTION = "relatedTransaction";
	
	public static final String SLASH = "\\";

	
}
