package com.anz.app.processor;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;
import java.text.NumberFormat;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.util.ArrayList;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Scanner;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVRecord;

import com.anz.app.constants.TransactionManagerConstants;
import com.anz.app.model.TransactionRecord;

/**
 * Handles the transaction management
 * 
 * @author Mathura
 *
 */
public interface TransactionManager {

	/**
	 * Process method
	 * 
	 * @throws IOException
	 */
	public default void process() throws IOException {
		int noOfTransactions = 0;
		double totalAmount = 0.00;
		Scanner scanner = new Scanner(System.in);
		List<String> reversalList;
		try {
			NumberFormat numberFormat = new DecimalFormat(TransactionManagerConstants.DECIMAL_NUMBER_FORMAT);
			numberFormat.getCurrencyInstance();

			System.out.print("Enter File Name : ");
			String inputFile = scanner.nextLine();

			System.out.print("Please enter the accountId : ");
			String acctId = scanner.nextLine();

			System.out.println("Please select the date range");
			System.out.print("Please enter from date (dd/MM/yyyy HH:mm:ss) : ");
			LocalDate startDate = readDate(scanner, TransactionManagerConstants.DATE_PATTERN);

			System.out.print("Please enter to date (dd/MM/yyyy HH:mm:ss) : ");
			LocalDate endDate = readDate(scanner, TransactionManagerConstants.DATE_PATTERN);

			if (endDate.isBefore(startDate))
				throw new ParseException("Invalid Date Format!", 0);

			List<TransactionRecord> listOfRecords = new ArrayList<TransactionRecord>();
			listOfRecords = readAndPopulateTheRecords(inputFile);
			reversalList = getReversalTransactions(listOfRecords);

			for (TransactionRecord record : listOfRecords) {
				double amount = 0.0;
				if ((record.getFromAccountId().contains(acctId) || record.getToAccountId().contains(acctId))) {
					if (checkIfWithinTheDateRange(startDate, record.getCreatedAt(), endDate)
							&& !reversalList.contains(record.getTransactionId())) {
						amount = record.getAmount();
						if (record.getFromAccountId().contains(acctId))
							amount *= -1;
						totalAmount = totalAmount + amount;
						noOfTransactions++;
					}
				}
			}
			System.out.println("Relative balance of the period is : " + numberFormat.format(totalAmount));
			System.out.println("Number of transactions included is : " + noOfTransactions);

		} catch (FileNotFoundException e1) {
			throw new FileNotFoundException("File not Found!");
		} catch (ParseException e2) {
			System.out.println("Invalid Date Format!");
			e2.printStackTrace();
		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			scanner.close();
		}
	}

	/**
	 * This method will read the input file and extract all the transaction
	 * records and populate into objects.
	 * 
	 * @return
	 * @throws FileNotFoundException
	 * @throws IOException
	 * @throws ParseException
	 */
	public default List<TransactionRecord> readAndPopulateTheRecords(String inputFile)
			throws FileNotFoundException, IOException, ParseException {

		List<TransactionRecord> listOfRecords = new ArrayList<TransactionRecord>();

		DateTimeFormatter format = DateTimeFormatter.ofPattern(TransactionManagerConstants.DATE_PATTERN);
		Reader reader;
		reader = new FileReader(System.getProperty("user.dir") + TransactionManagerConstants.SLASH + inputFile);
		Iterable<CSVRecord> records = CSVFormat.DEFAULT.withHeader(TransactionManagerConstants.HEADERS)
				.withFirstRecordAsHeader().parse(reader);

		records.forEach((csvRecord) -> {
			TransactionRecord transRecord = new TransactionRecord();
			LocalDate date = LocalDate.parse(csvRecord.get(TransactionManagerConstants.CREATED_AT).trim(), format);
			transRecord.setCreatedAt(date);
			transRecord.setAmount(Double.parseDouble(csvRecord.get(TransactionManagerConstants.AMOUNT)));
			transRecord.setFromAccountId(csvRecord.get(TransactionManagerConstants.FROM_ACCOUNT_ID));
			transRecord.setToAccountId(csvRecord.get(TransactionManagerConstants.TO_ACCOUNT_ID));
			transRecord.setTransactionType(csvRecord.get(TransactionManagerConstants.TRANSACTION_TYPE));
			transRecord.setTransactionId(csvRecord.get(TransactionManagerConstants.TRANSACTION_ID));

			if (csvRecord.isSet(TransactionManagerConstants.RELATED_TRANSACTION))
				transRecord.setRelatedTransaction(csvRecord.get(TransactionManagerConstants.RELATED_TRANSACTION));
			else
				transRecord.setRelatedTransaction(null);
			listOfRecords.add(transRecord);
		});

		return listOfRecords;
	}

	/**
	 * This method retrieves the list of transactions that need to be ignored.
	 * ie: any reversal transaction and the transactions related to this.
	 * 
	 * @param records
	 * @return
	 */
	public static List<String> getReversalTransactions(List<TransactionRecord> records) {
		ArrayList<String> reversalList = new ArrayList<String>();
		records.stream().forEach((record) -> {
			if (record.getTransactionType().contains(TransactionManagerConstants.REVERSAL)) {
				reversalList.add(record.getTransactionId().trim());
				reversalList.add(record.getRelatedTransaction().trim());
			}
		});

		return reversalList;
	}

	/**
	 * Gets user input date
	 * 
	 * @param scanner
	 * @param format
	 * @return
	 * @throws ParseException
	 */
	public static LocalDate readDate(Scanner scanner, String pattern) throws ParseException {
		DateTimeFormatter format = DateTimeFormatter.ofPattern(pattern);
		return LocalDate.parse(scanner.nextLine().trim(), format);
	}

	/**
	 * Returns boolean if particular date is within the range
	 * 
	 * @param startDate
	 * @param date
	 * @param endDate
	 * @return
	 */
	public static boolean checkIfWithinTheDateRange(LocalDate startDate, LocalDate date, LocalDate endDate) {
		return (!date.isBefore(startDate) && !date.isAfter(endDate));
	}
}