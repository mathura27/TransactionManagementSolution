package com.anz.app.starter;

import java.io.IOException;

import com.anz.app.processor.TransactionManager;;

/**
 * Main class of the application
 * @author Mathura
 *
 */
public class TransactionManagerLauncher implements TransactionManager {
	
	public static void main(String[] args) throws IOException {
		TransactionManager transactionManager = new TransactionManagerLauncher();
		transactionManager.process();
	}
}
