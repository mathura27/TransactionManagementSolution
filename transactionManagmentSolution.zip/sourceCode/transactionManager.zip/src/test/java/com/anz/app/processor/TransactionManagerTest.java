package com.anz.app.processor;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.time.*;
import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.Spy;
import org.mockito.runners.MockitoJUnitRunner;

import com.anz.app.constants.TransactionManagerConstants;
import com.anz.app.model.TransactionRecord;
import com.anz.app.processor.TransactionManager;
import com.anz.app.starter.TransactionManagerLauncher;

/**
 * Test class for TransactionManager
 * 
 * @author Mathura
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class TransactionManagerTest {

	@Spy
	@InjectMocks
	TransactionManager mockObj = new TransactionManagerLauncher();

	LocalDate startDate;
	LocalDate endDate;
	DateTimeFormatter format = DateTimeFormatter.ofPattern(TransactionManagerConstants.DATE_PATTERN);

	TransactionRecord transactionRecord1 = new TransactionRecord();
	TransactionRecord transactionRecord2 = new TransactionRecord();
	List<TransactionRecord> transactionList = new ArrayList<TransactionRecord>();

	@Before
	public void setup() throws Exception {

		startDate = LocalDate.parse("20/10/2018 12:00:00", format);
		endDate = LocalDate.parse("21/10/2018 12:00:00", format);

		transactionRecord1.setTransactionId("TX10004,");
		transactionRecord1.setAmount(10.50);
		transactionRecord1.setTransactionType(TransactionManagerConstants.REVERSAL);
		transactionRecord1.setRelatedTransaction("TX10003");

		transactionRecord2.setTransactionId("TX10001");
		transactionRecord2.setAmount(25.00);
		transactionRecord2.setTransactionType(TransactionManagerConstants.PAYMENT);
		transactionList.add(transactionRecord1);
		transactionList.add(transactionRecord2);
	}

	/**
	 * Tests the process method which receives inputs, processes them and
	 * provides the required output
	 * 
	 * @throws Exception
	 */
	@Test
	public void testProcess() throws Exception {
		Mockito.doNothing().when(mockObj).process();
	}

	/**
	 * Test to check if the date is not within the date range
	 * 
	 * @throws Exception
	 */
	@Test
	public void testCheckIfNotWithinTheDateRange() throws Exception {
		LocalDate date = LocalDate.parse("18/10/2018 14:00:00", format);
		Assert.assertEquals(false, TransactionManager.checkIfWithinTheDateRange(startDate, date, endDate));
	}

	/**
	 * Test to check if the date is within the date range
	 * 
	 * @throws Exception
	 */
	@Test
	public void testCheckIfWithinTheDateRange() throws Exception {
		LocalDate date = LocalDate.parse("20/10/2018 14:00:00", format);
		Assert.assertEquals(true, TransactionManager.checkIfWithinTheDateRange(startDate, date, endDate));
	}

	/**
	 * Test to check if the date is within the date range for invalid date
	 * format
	 * 
	 * @throws Exception
	 */
	@Test(expected = DateTimeParseException.class)
	public void testCheckIfNotWithinTheDateRangeInvalidFormat() throws Exception {
		LocalDate date = LocalDate.parse("20-10-2018 14:00:00", format);
		TransactionManager.checkIfWithinTheDateRange(startDate, date, endDate);
	}

	/**
	 * Test to get the reversal transactions
	 * 
	 * @throws Exception
	 */
	@Test
	public void testGetReversalTransactions() throws Exception {
		List<String> result = TransactionManager.getReversalTransactions(transactionList);
		Assert.assertEquals(2, result.size());
	}

	/**
	 * Test to get the reversal transactions for null list
	 * 
	 * @throws Exception
	 */
	@Test(expected = NullPointerException.class)
	public void testGetReversalTransactionsForNull() throws Exception {
		List<String> result = TransactionManager.getReversalTransactions(null);
		result.size();
	}
}
